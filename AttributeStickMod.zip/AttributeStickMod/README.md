# Attribute Stick (Minecraft 1.7.10, Forge 10.13.4.1614)

Right-click **any mob** with the Attribute Stick and an editor window opens.

**Recipe:** ender pearl / stick / diamond (top to bottom). Also in the Tools creative tab.
**Who can use it:** creative-mode players, ops, and anyone in singleplayer.

## What you can edit

| Setting | What it does |
|---|---|
| **Max health** | New max health; the mob is healed to full when you save (1 to 1024). |
| **Attack dmg** | Damage per hit in half-hearts (even cows get an attack attribute so they can hurt you). |
| **Speed** | Movement speed (0.25 is a normal zombie-ish speed, 0.7 is very fast). |
| **Knockback** | Extra knockback the mob deals to *whatever it hits*. 0 = normal. About 5 = big shove, 10+ = launched far away. |
| **KB resist** | 0 to 1. At 1 the mob can't be knocked back. |
| **Follow range** | How far away it notices targets. |
| **Size** | Size multiplier (0.1 to 16). Changes both the model and the hitbox. |
| **Custom name** | Name tag shown above the mob. |
| **Boss bar** | ON shows a boss bar for the mob (nearest one within 64 blocks), with your **Boss bar title** (blank = the mob's name). |
| **Behaviour** | Click to cycle: **Vanilla** (unchanged), **Hostile** (attacks you on sight, even a cow), **Normal** (peaceful until you hit it, then fights back), **Friendly** (never attacks anything, even if hit). |
| **Invulnerable** | Takes no damage (void and creative-mode hits still work). |
| **Equipment slots** | Five slots at the top right: Hand, Head, Chest, Legs, Feet. Put items in or take them out; shift-click works. Whatever is in the slots when the window closes becomes the mob's gear. |

Buttons: **Save & close** applies the number/name/toggle settings. **Reset mob to original** restores
the mob's original attributes, size, name and behaviour. Esc closes without saving the settings
(equipment slots still apply when the window closes).

Edits are saved with the mob in the world and survive restarts.

## Limits worth knowing
* Only mobs that walk (`EntityCreature`: zombies, cows, pigs, villagers, ...) get Hostile/Normal behaviour.
  Flying/swimming mobs (bats, squids) still get Friendly protection and all the numbers.
* Equipment only *shows* on mobs with a humanoid model (zombies, skeletons, pigmen). Cows will hold it invisibly.
* Armor/weapons you put on a mob are not guaranteed to drop when it dies.
* Players cannot be edited, only mobs.
* Very large sizes can push a mob into walls and suffocate it.

## Building
1. Set up a Forge 1.7.10 workspace (the official MDK, build 10.13.4.1614).
2. Copy this project's `src/` folder over the MDK's `src/`.
3. `gradlew build`; the jar appears in `build/libs/`.

`build.gradle` here is the same idea using a maintained ForgeGradle fork that still resolves today
(anatawa12's). I couldn't verify it, so if it fails, use the MDK's own build files instead.

## Files
* `AttributeStickMod` - mod entry, item, recipe, network channel
* `StickEvents` - right-click hook, knockback, friendly/invulnerable rules, re-applying edits on load
* `MobEditor` / `MobSettings` / `AiMode` - applying the settings, saving them, hostile/normal/friendly AI
* `ContainerMobEditor` / `GuiMobEditor` - the editor window
* `ClientEvents` - custom size rendering and the boss bar
* `Packets` - open / save / sync messages
