package com.attributestick;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

/**
 * The stick itself has no behaviour of its own: right-clicking a mob with it is handled by
 * StickEvents#onInteract (that way the mob's own right-click action, e.g. a villager's trade
 * window, can't take over first).
 */
public class ItemAttributeStick extends Item {

    public ItemAttributeStick() {
        setUnlocalizedName("attributeStick");
        setTextureName(AttributeStickMod.MODID + ":attribute_stick");
        setMaxStackSize(1);
        setCreativeTab(CreativeTabs.tabTools);
        setFull3D();
    }
}
