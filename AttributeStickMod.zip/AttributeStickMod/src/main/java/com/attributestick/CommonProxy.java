package com.attributestick;

public class CommonProxy {

    public void init() {
        // server: nothing client-side to register
    }

    /** Client only: remember the mob's values until the GUI opens. */
    public void cacheSettings(int entityId, MobSettings settings) {
    }

    /** Client only: apply size / boss bar info sent by the server. */
    public void handleVisual(Packets.Visual visual) {
    }
}
