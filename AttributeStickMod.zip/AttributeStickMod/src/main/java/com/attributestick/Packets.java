package com.attributestick;

import cpw.mods.fml.common.network.ByteBufUtils;
import cpw.mods.fml.common.network.simpleimpl.IMessage;
import cpw.mods.fml.common.network.simpleimpl.IMessageHandler;
import cpw.mods.fml.common.network.simpleimpl.MessageContext;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;

/** The three network messages of the mod. */
public final class Packets {

    private Packets() {}

    /** Server -> client: current values of the mob, sent right before the GUI opens. */
    public static class Open implements IMessage {
        public int entityId;
        public MobSettings settings;

        public Open() {}

        public Open(int entityId, MobSettings settings) {
            this.entityId = entityId;
            this.settings = settings;
        }

        @Override
        public void fromBytes(ByteBuf buf) {
            entityId = buf.readInt();
            settings = MobSettings.fromBytes(buf);
        }

        @Override
        public void toBytes(ByteBuf buf) {
            buf.writeInt(entityId);
            settings.toBytes(buf);
        }

        public static class Handler implements IMessageHandler<Open, IMessage> {
            @Override
            public IMessage onMessage(Open m, MessageContext ctx) {
                AttributeStickMod.proxy.cacheSettings(m.entityId, m.settings);
                return null;
            }
        }
    }

    /** Client -> server: the player pressed "Save" (or "Reset") in the GUI. */
    public static class Apply implements IMessage {
        public int entityId;
        public boolean reset;
        public MobSettings settings;

        public Apply() {}

        public Apply(int entityId, boolean reset, MobSettings settings) {
            this.entityId = entityId;
            this.reset = reset;
            this.settings = settings;
        }

        @Override
        public void fromBytes(ByteBuf buf) {
            entityId = buf.readInt();
            reset = buf.readBoolean();
            settings = MobSettings.fromBytes(buf);
        }

        @Override
        public void toBytes(ByteBuf buf) {
            buf.writeInt(entityId);
            buf.writeBoolean(reset);
            settings.toBytes(buf);
        }

        public static class Handler implements IMessageHandler<Apply, IMessage> {
            @Override
            public IMessage onMessage(final Apply m, MessageContext ctx) {
                final EntityPlayerMP player = ctx.getServerHandler().playerEntity;
                Scheduler.SERVER.add(new Runnable() {
                    @Override
                    public void run() {
                        // never trust the client: re-check permission, held item and distance
                        if (!StickEvents.canEdit(player)) return;
                        ItemStack held = player.getHeldItem();
                        if (held == null || held.getItem() != AttributeStickMod.stick) return;
                        Entity e = player.worldObj.getEntityByID(m.entityId);
                        if (!(e instanceof EntityLiving)) return;
                        if (player.getDistanceSqToEntity(e) > 144.0) return;

                        EntityLiving mob = (EntityLiving) e;
                        if (m.reset) {
                            MobEditor.reset(mob);
                        } else {
                            MobEditor.apply(mob, m.settings, true);
                        }
                        MobEditor.broadcastVisual(mob);
                    }
                });
                return null;
            }
        }
    }

    /** Server -> clients near the mob: size and boss bar (clients can't compute these themselves). */
    public static class Visual implements IMessage {
        public int entityId;
        public float scale;
        public boolean boss;
        public String bossName;

        public Visual() {}

        public Visual(int entityId, float scale, boolean boss, String bossName) {
            this.entityId = entityId;
            this.scale = scale;
            this.boss = boss;
            this.bossName = bossName;
        }

        @Override
        public void fromBytes(ByteBuf buf) {
            entityId = buf.readInt();
            scale = buf.readFloat();
            boss = buf.readBoolean();
            bossName = ByteBufUtils.readUTF8String(buf);
        }

        @Override
        public void toBytes(ByteBuf buf) {
            buf.writeInt(entityId);
            buf.writeFloat(scale);
            buf.writeBoolean(boss);
            ByteBufUtils.writeUTF8String(buf, bossName);
        }

        public static class Handler implements IMessageHandler<Visual, IMessage> {
            @Override
            public IMessage onMessage(Visual m, MessageContext ctx) {
                AttributeStickMod.proxy.handleVisual(m);
                return null;
            }
        }
    }
}
