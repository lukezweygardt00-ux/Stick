package com.attributestick;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Slot;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The editor window. Left: number fields. Right: equipment slots, names, toggles.
 * Everything is drawn with plain rectangles, so no GUI texture file is needed.
 */
@SideOnly(Side.CLIENT)
public class GuiMobEditor extends GuiContainer {

    private static final String[] MODE_NAMES = {
            "Behaviour: Vanilla (unchanged)",
            "Behaviour: Hostile (attacks you)",
            "Behaviour: Normal (fights if hit)",
            "Behaviour: Friendly (never attacks)"
    };
    private static final String[] SLOT_LABELS = {"Hand", "Head", "Chest", "Legs", "Feet"};
    private static final String[] ROW_LABELS = {
            "Max health", "Attack dmg", "Speed", "Knockback", "KB resist", "Follow range", "Size"
    };

    private static final int ID_MODE = 1;
    private static final int ID_BOSS = 2;
    private static final int ID_INVULN = 3;
    private static final int ID_SAVE = 4;
    private static final int ID_RESET = 5;

    private final EntityLiving mob;
    private final MobSettings start;

    private final List<GuiTextField> fields = new ArrayList<GuiTextField>();
    private final List<GuiTextField> numeric = new ArrayList<GuiTextField>();
    private GuiTextField fHealth, fDamage, fSpeed, fKnock, fKbRes, fFollow, fSize, fName, fBoss;

    private int mode;
    private boolean bossBar;
    private boolean invulnerable;
    private GuiButton bMode, bBoss, bInvuln;

    public GuiMobEditor(EntityPlayer player, EntityLiving mob) {
        super(new ContainerMobEditor(player, mob));
        this.mob = mob;
        this.xSize = ContainerMobEditor.GUI_W;
        this.ySize = ContainerMobEditor.GUI_H;

        MobSettings cached = ClientEvents.PENDING.remove(Integer.valueOf(mob.getEntityId()));
        this.start = cached != null ? cached : MobSettings.read(mob);
        this.mode = start.mode;
        this.bossBar = start.bossBar;
        this.invulnerable = start.invulnerable;
    }

    // ---- setup ---------------------------------------------------------------------------

    private static String fmt(double d) {
        return new DecimalFormat("0.####", DecimalFormatSymbols.getInstance(Locale.US)).format(d);
    }

    private GuiTextField addField(int relX, int relY, int w, String text, int maxLen, boolean isNumber) {
        GuiTextField f = new GuiTextField(fontRendererObj, guiLeft + relX, guiTop + relY, w, 14);
        f.setMaxStringLength(maxLen);
        f.setText(text);
        fields.add(f);
        if (isNumber) numeric.add(f);
        return f;
    }

    @Override
    public void initGui() {
        super.initGui();
        Keyboard.enableRepeatEvents(true);
        fields.clear();
        numeric.clear();
        buttonList.clear();

        fHealth = addField(84, 22, 64, fmt(start.maxHealth), 10, true);
        fDamage = addField(84, 43, 64, fmt(start.damage), 10, true);
        fSpeed = addField(84, 64, 64, fmt(start.speed), 10, true);
        fKnock = addField(84, 85, 64, fmt(start.knockback), 10, true);
        fKbRes = addField(84, 106, 64, fmt(start.kbResist), 10, true);
        fFollow = addField(84, 127, 64, fmt(start.followRange), 10, true);
        fSize = addField(84, 148, 64, fmt(start.scale), 10, true);
        fName = addField(162, 58, 146, start.name, 64, false);
        fBoss = addField(162, 86, 146, start.bossName, 64, false);

        bMode = new GuiButton(ID_MODE, guiLeft + 162, guiTop + 106, 146, 18, "");
        bBoss = new GuiButton(ID_BOSS, guiLeft + 162, guiTop + 128, 146, 18, "");
        bInvuln = new GuiButton(ID_INVULN, guiLeft + 162, guiTop + 150, 146, 18, "");
        buttonList.add(bMode);
        buttonList.add(bBoss);
        buttonList.add(bInvuln);
        buttonList.add(new GuiButton(ID_SAVE, guiLeft + 8, guiTop + 172, 148, 18, "Save & close"));
        buttonList.add(new GuiButton(ID_RESET, guiLeft + 162, guiTop + 172, 146, 18, "Reset mob to original"));
        refreshButtons();
    }

    private void refreshButtons() {
        bMode.displayString = MODE_NAMES[mode];
        bBoss.displayString = "Boss bar: " + (bossBar ? "ON" : "OFF");
        bInvuln.displayString = "Invulnerable: " + (invulnerable ? "ON" : "OFF");
    }

    @Override
    public void onGuiClosed() {
        Keyboard.enableRepeatEvents(false);
        super.onGuiClosed();
    }

    // ---- reading the form -----------------------------------------------------------------

    private static double parse(GuiTextField f, double fallback) {
        try {
            return Double.parseDouble(f.getText().trim().replace(',', '.'));
        } catch (NumberFormatException ex) {
            return fallback;
        }
    }

    private MobSettings build() {
        MobSettings s = new MobSettings();
        s.maxHealth = parse(fHealth, start.maxHealth);
        s.damage = parse(fDamage, start.damage);
        s.speed = parse(fSpeed, start.speed);
        s.knockback = (float) parse(fKnock, start.knockback);
        s.kbResist = parse(fKbRes, start.kbResist);
        s.followRange = parse(fFollow, start.followRange);
        s.scale = (float) parse(fSize, start.scale);
        s.name = fName.getText();
        s.bossName = fBoss.getText();
        s.bossBar = bossBar;
        s.invulnerable = invulnerable;
        s.mode = mode;
        return s.sanitize();
    }

    private void send(boolean reset) {
        MobSettings s = reset ? new MobSettings() : build();
        AttributeStickMod.network.sendToServer(new Packets.Apply(mob.getEntityId(), reset, s));
        mc.thePlayer.closeScreen();
    }

    // ---- input ---------------------------------------------------------------------------

    @Override
    protected void actionPerformed(GuiButton button) {
        switch (button.id) {
            case ID_MODE:
                mode = (mode + 1) % MODE_NAMES.length;
                break;
            case ID_BOSS:
                bossBar = !bossBar;
                break;
            case ID_INVULN:
                invulnerable = !invulnerable;
                break;
            case ID_SAVE:
                send(false);
                return;
            case ID_RESET:
                send(true);
                return;
            default:
                break;
        }
        refreshButtons();
    }

    @Override
    protected void keyTyped(char c, int keyCode) {
        if (keyCode == Keyboard.KEY_ESCAPE) {
            mc.thePlayer.closeScreen();
            return;
        }
        for (int i = 0; i < fields.size(); i++) {
            GuiTextField f = fields.get(i);
            if (!f.isFocused()) continue;

            if (keyCode == Keyboard.KEY_TAB) {
                f.setFocused(false);
                fields.get((i + 1) % fields.size()).setFocused(true);
                return;
            }
            boolean allowed = true;
            if (numeric.contains(f) && c >= 32 && c != 127 && "0123456789.,-".indexOf(c) < 0) {
                allowed = false;   // ignore letters in number boxes
            }
            if (allowed) f.textboxKeyTyped(c, keyCode);
            return;   // a focused box eats the key, so typing 'e' never closes the window
        }
        super.keyTyped(c, keyCode);
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int button) {
        super.mouseClicked(mouseX, mouseY, button);
        for (GuiTextField f : fields) {
            f.mouseClicked(mouseX, mouseY, button);
        }
    }

    @Override
    public void updateScreen() {
        super.updateScreen();
        for (GuiTextField f : fields) {
            f.updateCursorCounter();
        }
    }

    // ---- drawing -------------------------------------------------------------------------

    @Override
    protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
        int x = guiLeft, y = guiTop;
        drawRect(x, y, x + xSize, y + ySize, 0xFF1E1E1E);                   // border
        drawRect(x + 2, y + 2, x + xSize - 2, y + ySize - 2, 0xFFC6C6C6);   // panel

        for (Object o : inventorySlots.inventorySlots) {
            Slot s = (Slot) o;
            int sx = x + s.xDisplayPosition;
            int sy = y + s.yDisplayPosition;
            drawRect(sx - 1, sy - 1, sx + 17, sy + 17, 0xFF373737);
            drawRect(sx, sy, sx + 16, sy + 16, 0xFF8B8B8B);
        }
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int mouseX, int mouseY) {
        int color = 0x404040;
        fontRendererObj.drawString("Editing: " + mob.getCommandSenderName(), 8, 8, color);
        for (int i = 0; i < ROW_LABELS.length; i++) {
            fontRendererObj.drawString(ROW_LABELS[i], 8, 25 + i * 21, color);
        }
        for (int i = 0; i < SLOT_LABELS.length; i++) {
            fontRendererObj.drawString(SLOT_LABELS[i], ContainerMobEditor.EQUIP_X + i * ContainerMobEditor.EQUIP_STEP, 13, color);
        }
        fontRendererObj.drawString("Custom name", 162, 47, color);
        fontRendererObj.drawString("Boss bar title", 162, 75, color);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        super.drawScreen(mouseX, mouseY, partialTicks);
        GL11.glDisable(GL11.GL_LIGHTING);
        for (GuiTextField f : fields) {
            f.drawTextBox();
        }
    }
}
