package com.attributestick;

import cpw.mods.fml.common.network.IGuiHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;

/** GUI id 0 = the mob editor. The x coordinate carries the mob's entity id. */
public class GuiHandler implements IGuiHandler {

    @Override
    public Object getServerGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
        Entity e = world.getEntityByID(x);
        if (e instanceof EntityLiving) {
            return new ContainerMobEditor(player, (EntityLiving) e);
        }
        return null;
    }

    @Override
    public Object getClientGuiElement(int id, EntityPlayer player, World world, int x, int y, int z) {
        Entity e = world.getEntityByID(x);
        if (e instanceof EntityLiving) {
            return new GuiMobEditor(player, (EntityLiving) e);
        }
        return null;
    }
}
