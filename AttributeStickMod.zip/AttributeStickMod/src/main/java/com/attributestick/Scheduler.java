package com.attributestick;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Forge 1.7.10 delivers network packets on the netty thread, but the world must only be touched
 * on the main thread. Packet handlers drop a Runnable in here; it is run on the next tick.
 */
public final class Scheduler {

    public static final Queue<Runnable> SERVER = new ConcurrentLinkedQueue<Runnable>();
    public static final Queue<Runnable> CLIENT = new ConcurrentLinkedQueue<Runnable>();

    private Scheduler() {}

    public static void drain(Queue<Runnable> q) {
        Runnable r;
        while ((r = q.poll()) != null) {
            try {
                r.run();
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
    }
}
