package com.attributestick;

import cpw.mods.fml.common.eventhandler.EventPriority;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.boss.BossStatus;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.client.event.RenderLivingEvent;
import org.lwjgl.opengl.GL11;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Client only: draws mobs at their custom size and shows the custom boss bar. */
@SideOnly(Side.CLIENT)
public class ClientEvents {

    /** Mob values received from the server, waiting for the GUI to open. */
    public static final Map<Integer, MobSettings> PENDING = new ConcurrentHashMap<Integer, MobSettings>();

    private static NBTTagCompound settingsOf(EntityLivingBase e) {
        NBTTagCompound d = e.getEntityData();
        if (d.hasNoTags() || !d.hasKey(MobSettings.TAG, 10)) return null;
        return d.getCompoundTag(MobSettings.TAG);
    }

    // ---- custom size -----------------------------------------------------------------------

    private static float scaleOf(EntityLivingBase e) {
        NBTTagCompound t = settingsOf(e);
        if (t == null) return 1.0F;
        float s = t.getFloat("Scale");
        return s <= 0.0F ? 1.0F : s;
    }

    // LOWEST so that if another mod cancels the render first, our matrix push never happens unbalanced
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onRenderPre(RenderLivingEvent.Pre event) {
        float s = scaleOf(event.entity);
        if (s == 1.0F) return;
        GL11.glPushMatrix();
        GL11.glTranslated(event.x, event.y, event.z);
        GL11.glScalef(s, s, s);
        GL11.glTranslated(-event.x, -event.y, -event.z);
    }

    @SubscribeEvent
    public void onRenderPost(RenderLivingEvent.Post event) {
        if (scaleOf(event.entity) != 1.0F) {
            GL11.glPopMatrix();
        }
    }

    // ---- boss bar --------------------------------------------------------------------------

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Scheduler.drain(Scheduler.CLIENT);

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.thePlayer == null) return;
        if (mc.thePlayer.ticksExisted % 4 != 0) return;

        EntityLivingBase best = null;
        String title = null;
        double bestDist = 64.0 * 64.0;

        for (Object o : mc.theWorld.loadedEntityList) {
            if (!(o instanceof EntityLivingBase)) continue;
            EntityLivingBase e = (EntityLivingBase) o;
            if (!e.isEntityAlive()) continue;
            NBTTagCompound t = settingsOf(e);
            if (t == null || !t.getBoolean("BossBar")) continue;
            double d = e.getDistanceSqToEntity(mc.thePlayer);
            if (d < bestDist) {
                bestDist = d;
                best = e;
                title = t.getString("BossName");
            }
        }

        if (best != null) {
            if (title == null || title.length() == 0) {
                title = best.getCommandSenderName();
            }
            // these static fields are what the vanilla boss bar (Wither / Ender Dragon) draws from
            BossStatus.healthScale = best.getHealth() / best.getMaxHealth();
            BossStatus.statusBarTime = 100;
            BossStatus.bossName = title;
            BossStatus.hasColorModifier = false;
        }
    }
}
