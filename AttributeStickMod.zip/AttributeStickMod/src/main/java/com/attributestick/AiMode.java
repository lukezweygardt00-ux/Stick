package com.attributestick;

import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIAttackOnCollide;
import net.minecraft.entity.ai.EntityAIAvoidEntity;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.ai.EntityAIPanic;
import net.minecraft.entity.ai.EntityAITasks;
import net.minecraft.entity.player.EntityPlayer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Hostile / Normal / Friendly behaviour for any mob.
 *
 *  VANILLA  - untouched.
 *  HOSTILE  - attacks players on sight (even cows).
 *  NORMAL   - peaceful until you hurt it, then it fights back.
 *  FRIENDLY - never attacks anything, even when hit.
 *
 * Only works on EntityCreature mobs (everything that walks). Flying/swimming mobs only get the
 * FRIENDLY protection.
 */
public final class AiMode {

    /** Marker so we can find and remove the AI goals we added. */
    public interface StickAI {}

    public static class AttackAI extends EntityAIAttackOnCollide implements StickAI {
        public AttackAI(EntityCreature c) {
            super(c, 1.1D, false);
        }
    }

    public static class TargetAI extends EntityAINearestAttackableTarget implements StickAI {
        public TargetAI(EntityCreature c) {
            super(c, EntityPlayer.class, 0, true);
        }
    }

    public static class HurtAI extends EntityAIHurtByTarget implements StickAI {
        public HurtAI(EntityCreature c) {
            super(c, true);
        }
    }

    /** Vanilla goals we took away, so choosing "Vanilla" again can give them back. */
    private static final Map<EntityLiving, List<Object[]>> STASH =
            new WeakHashMap<EntityLiving, List<Object[]>>();

    private AiMode() {}

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void removeOurs(EntityAITasks ai) {
        List toRemove = new ArrayList();
        for (Object o : ai.taskEntries) {
            EntityAITasks.EntityAITaskEntry entry = (EntityAITasks.EntityAITaskEntry) o;
            if (entry.action instanceof StickAI) {
                toRemove.add(entry.action);
            }
        }
        for (Object o : toRemove) {
            ai.removeTask((EntityAIBase) o);
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static void stash(EntityLiving e, EntityAITasks ai, boolean isTarget, boolean onlyPanic) {
        List<Object[]> saved = STASH.get(e);
        if (saved == null) {
            saved = new ArrayList<Object[]>();
            STASH.put(e, saved);
        }
        List copy = new ArrayList(ai.taskEntries);
        for (Object o : copy) {
            EntityAITasks.EntityAITaskEntry entry = (EntityAITasks.EntityAITaskEntry) o;
            if (entry.action instanceof StickAI) continue;
            boolean match = isTarget
                    || entry.action instanceof EntityAIPanic
                    || entry.action instanceof EntityAIAvoidEntity;
            if (onlyPanic && !(entry.action instanceof EntityAIPanic
                    || entry.action instanceof EntityAIAvoidEntity)) {
                match = false;
            }
            if (match) {
                saved.add(new Object[] {Boolean.valueOf(isTarget), Integer.valueOf(entry.priority), entry.action});
                ai.removeTask(entry.action);
            }
        }
    }

    private static void restore(EntityLiving e) {
        List<Object[]> saved = STASH.remove(e);
        if (saved == null) return;
        for (Object[] item : saved) {
            boolean isTarget = ((Boolean) item[0]).booleanValue();
            int priority = ((Integer) item[1]).intValue();
            EntityAIBase action = (EntityAIBase) item[2];
            (isTarget ? e.targetTasks : e.tasks).addTask(priority, action);
        }
    }

    public static void apply(EntityLivingBase base, int mode) {
        if (!(base instanceof EntityLiving)) return;
        EntityLiving e = (EntityLiving) base;

        removeOurs(e.tasks);
        removeOurs(e.targetTasks);
        restore(e);

        if (mode == MobSettings.MODE_VANILLA) return;

        if (mode == MobSettings.MODE_FRIENDLY) {
            stash(e, e.targetTasks, true, false);
            e.setAttackTarget(null);
            return;
        }

        if (!(e instanceof EntityCreature)) return;
        EntityCreature c = (EntityCreature) e;

        // hostile/normal mobs must not run away from the player
        stash(c, c.tasks, false, true);

        if (mode == MobSettings.MODE_HOSTILE) {
            c.tasks.addTask(1, new AttackAI(c));
            c.targetTasks.addTask(1, new TargetAI(c));
        } else { // NORMAL: only fights back when hurt
            stash(c, c.targetTasks, true, false);
            c.setAttackTarget(null);
            c.tasks.addTask(1, new AttackAI(c));
            c.targetTasks.addTask(1, new HurtAI(c));
        }
    }
}
