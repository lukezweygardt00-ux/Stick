package com.attributestick;

import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

/**
 * Holds the five equipment slots of the mob (hand, head, chest, legs, feet) next to the player's
 * inventory. Whatever is in the slots when the window closes becomes the mob's gear.
 */
public class ContainerMobEditor extends Container {

    /** Layout shared with the GUI. */
    public static final int GUI_W = 320;
    public static final int GUI_H = 276;
    public static final int EQUIP_X = 162;
    public static final int EQUIP_Y = 24;
    public static final int EQUIP_STEP = 30;
    public static final int INV_X = (GUI_W - 162) / 2;
    public static final int INV_Y = GUI_H - 82;

    public static final int SLOT_COUNT = 5;
    /** Display order (hand, head, chest, legs, feet) -> EntityLiving equipment index (0 = hand, 1 = boots ... 4 = helmet). */
    public static final int[] MOB_SLOT = {0, 4, 3, 2, 1};

    public final EntityLiving mob;
    private final IInventory equip = new InventoryBasic("Mob equipment", false, SLOT_COUNT);

    public ContainerMobEditor(EntityPlayer player, EntityLiving mob) {
        this.mob = mob;

        for (int i = 0; i < SLOT_COUNT; i++) {
            ItemStack current = mob.getEquipmentInSlot(MOB_SLOT[i]);
            equip.setInventorySlotContents(i, current == null ? null : current.copy());
            addSlotToContainer(new Slot(equip, i, EQUIP_X + i * EQUIP_STEP, EQUIP_Y) {
                @Override
                public int getSlotStackLimit() {
                    return 1;
                }
            });
        }
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlotToContainer(new Slot(player.inventory, col + row * 9 + 9,
                        INV_X + col * 18, INV_Y + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlotToContainer(new Slot(player.inventory, col, INV_X + col * 18, INV_Y + 58));
        }
    }

    @Override
    public boolean canInteractWith(EntityPlayer player) {
        ItemStack held = player.getHeldItem();
        return mob.isEntityAlive()
                && held != null && held.getItem() == AttributeStickMod.stick
                && player.getDistanceSqToEntity(mob) < 144.0;
    }

    @Override
    public void onContainerClosed(EntityPlayer player) {
        super.onContainerClosed(player);   // gives the cursor item back
        if (player.worldObj.isRemote) return;

        for (int i = 0; i < SLOT_COUNT; i++) {
            ItemStack stack = equip.getStackInSlot(i);
            if (mob.isEntityAlive()) {
                mob.setCurrentItemOrArmor(MOB_SLOT[i], stack);
            } else if (stack != null) {
                player.dropPlayerItemWithRandomChoice(stack, false);   // mob died while editing
            }
        }
    }

    private static int equipSlotFor(ItemStack stack) {
        if (stack.getItem() instanceof ItemArmor) {
            // armorType: 0 helmet, 1 chestplate, 2 leggings, 3 boots -> display slots 1..4
            return ((ItemArmor) stack.getItem()).armorType + 1;
        }
        return 0;   // anything else goes in the hand
    }

    @Override
    public ItemStack transferStackInSlot(EntityPlayer player, int index) {
        ItemStack result = null;
        Slot slot = (Slot) inventorySlots.get(index);
        if (slot != null && slot.getHasStack()) {
            ItemStack stack = slot.getStack();
            result = stack.copy();

            if (index < SLOT_COUNT) {
                // equipment -> player inventory
                if (!mergeItemStack(stack, SLOT_COUNT, inventorySlots.size(), true)) {
                    return null;
                }
            } else {
                // player inventory -> matching equipment slot (if free)
                int target = equipSlotFor(stack);
                Slot targetSlot = (Slot) inventorySlots.get(target);
                if (targetSlot.getHasStack()) {
                    return null;
                }
                targetSlot.putStack(stack.splitStack(1));
            }

            if (stack.stackSize == 0) {
                slot.putStack(null);
            } else {
                slot.onSlotChanged();
            }
        }
        return result;
    }
}
