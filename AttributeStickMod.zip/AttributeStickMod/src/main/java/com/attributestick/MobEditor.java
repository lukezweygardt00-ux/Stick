package com.attributestick;

import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.relauncher.ReflectionHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.nbt.NBTTagCompound;

import java.lang.reflect.Method;

/** Applies MobSettings to a mob. Server side, except applyVisualClient/applySize which run on both. */
public final class MobEditor {

    private static Method setSizeMethod;

    private MobEditor() {}

    // ---- originals (for Reset) -----------------------------------------------------------

    /** Remember the mob's untouched values the first time anything is changed. */
    public static void ensureOriginals(EntityLivingBase e) {
        NBTTagCompound root = e.getEntityData();
        if (root.hasKey(MobSettings.ORIG, 10)) return;
        NBTTagCompound o = new NBTTagCompound();
        o.setDouble("MaxHealth", MobSettings.base(e, SharedMonsterAttributes.maxHealth, e.getMaxHealth()));
        o.setDouble("Damage", MobSettings.base(e, SharedMonsterAttributes.attackDamage, 2.0));
        o.setDouble("Speed", MobSettings.base(e, SharedMonsterAttributes.movementSpeed, 0.25));
        o.setDouble("KbResist", MobSettings.base(e, SharedMonsterAttributes.knockbackResistance, 0.0));
        o.setDouble("FollowRange", MobSettings.base(e, SharedMonsterAttributes.followRange, 32.0));
        o.setFloat("Width", e.width);
        o.setFloat("Height", e.height);
        root.setTag(MobSettings.ORIG, o);
    }

    // ---- attributes ---------------------------------------------------------------------

    private static void setBase(EntityLivingBase e, IAttribute attr, double value) {
        IAttributeInstance a = e.getEntityAttribute(attr);
        if (a == null) {
            // e.g. cows have no attack damage attribute; add it so they can fight
            a = e.getAttributeMap().registerAttribute(attr);
        }
        a.setBaseValue(value);
    }

    // ---- size ---------------------------------------------------------------------------

    private static void setSize(Entity e, float w, float h) {
        try {
            if (setSizeMethod == null) {
                setSizeMethod = ReflectionHelper.findMethod(Entity.class, e,
                        new String[] {"setSize", "func_70105_a"}, float.class, float.class);
            }
            setSizeMethod.invoke(e, Float.valueOf(w), Float.valueOf(h));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /** Resize the hitbox to originalSize * scale. Safe to call every tick (only acts on change). */
    public static void applySize(EntityLivingBase e, float scale) {
        ensureOriginals(e);
        NBTTagCompound o = e.getEntityData().getCompoundTag(MobSettings.ORIG);
        float w = o.getFloat("Width") * scale;
        float h = o.getFloat("Height") * scale;
        if (Math.abs(e.width - w) > 0.001F || Math.abs(e.height - h) > 0.001F) {
            setSize(e, w, h);
        }
    }

    // ---- apply --------------------------------------------------------------------------

    /**
     * @param heal true when the player pressed Save (mob is healed to its new max health);
     *             false when just re-applying saved settings after a world load.
     */
    public static void apply(EntityLivingBase e, MobSettings s, boolean heal) {
        ensureOriginals(e);
        s.sanitize();

        setBase(e, SharedMonsterAttributes.maxHealth, s.maxHealth);
        setBase(e, SharedMonsterAttributes.attackDamage, s.damage);
        setBase(e, SharedMonsterAttributes.movementSpeed, s.speed);
        setBase(e, SharedMonsterAttributes.knockbackResistance, s.kbResist);
        setBase(e, SharedMonsterAttributes.followRange, s.followRange);
        if (heal) {
            e.setHealth(e.getMaxHealth());
        } else if (e.getHealth() > e.getMaxHealth()) {
            e.setHealth(e.getMaxHealth());
        }

        applySize(e, s.scale);

        if (e instanceof EntityLiving) {
            EntityLiving el = (EntityLiving) e;
            el.setCustomNameTag(s.name);
            el.setAlwaysRenderNameTag(s.name.length() > 0);
        }

        e.getEntityData().setTag(MobSettings.TAG, s.toTag());
        AiMode.apply(e, s.mode);
    }

    /** Put the mob back exactly how it was before the stick touched it. */
    public static void reset(EntityLivingBase e) {
        NBTTagCompound root = e.getEntityData();
        if (!root.hasKey(MobSettings.ORIG, 10)) return;
        NBTTagCompound o = root.getCompoundTag(MobSettings.ORIG);

        setBase(e, SharedMonsterAttributes.maxHealth, o.getDouble("MaxHealth"));
        setBase(e, SharedMonsterAttributes.attackDamage, o.getDouble("Damage"));
        setBase(e, SharedMonsterAttributes.movementSpeed, o.getDouble("Speed"));
        setBase(e, SharedMonsterAttributes.knockbackResistance, o.getDouble("KbResist"));
        setBase(e, SharedMonsterAttributes.followRange, o.getDouble("FollowRange"));
        e.setHealth(e.getMaxHealth());

        applySize(e, 1.0F);
        if (e instanceof EntityLiving) {
            ((EntityLiving) e).setCustomNameTag("");
            ((EntityLiving) e).setAlwaysRenderNameTag(false);
        }
        AiMode.apply(e, MobSettings.MODE_VANILLA);
        root.removeTag(MobSettings.TAG);
    }

    /** Re-apply saved settings when a mob is loaded into the world (AI goals are not saved by vanilla). */
    public static void applyStored(EntityLivingBase e) {
        NBTTagCompound root = e.getEntityData();
        if (!root.hasKey(MobSettings.TAG, 10)) return;
        apply(e, MobSettings.fromTag(root.getCompoundTag(MobSettings.TAG)), false);
    }

    // ---- syncing the visual parts to clients ---------------------------------------------

    /** Tell every player near the mob its size and boss-bar settings (clients can't read them otherwise). */
    public static void broadcastVisual(EntityLivingBase e) {
        float scale = 1.0F;
        boolean boss = false;
        String bossName = "";
        NBTTagCompound root = e.getEntityData();
        if (root.hasKey(MobSettings.TAG, 10)) {
            NBTTagCompound t = root.getCompoundTag(MobSettings.TAG);
            scale = t.getFloat("Scale");
            if (scale <= 0.0F) scale = 1.0F;
            boss = t.getBoolean("BossBar");
            bossName = t.getString("BossName");
        }
        AttributeStickMod.network.sendToAllAround(
                new Packets.Visual(e.getEntityId(), scale, boss, bossName),
                new NetworkRegistry.TargetPoint(e.dimension, e.posX, e.posY, e.posZ, 160.0));
    }

    /** Client side: remember what the server told us about this mob. */
    public static void applyVisualClient(EntityLivingBase e, float scale, boolean boss, String bossName) {
        ensureOriginals(e);
        NBTTagCompound root = e.getEntityData();
        NBTTagCompound t = new NBTTagCompound();
        t.setFloat("Scale", scale);
        t.setBoolean("BossBar", boss);
        t.setString("BossName", bossName);
        root.setTag(MobSettings.TAG, t);
        applySize(e, scale);
    }
}
