package com.attributestick;

import cpw.mods.fml.common.FMLCommonHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;

public class ClientProxy extends CommonProxy {

    @Override
    public void init() {
        ClientEvents events = new ClientEvents();
        FMLCommonHandler.instance().bus().register(events);   // client ticks
        MinecraftForge.EVENT_BUS.register(events);            // render events
    }

    @Override
    public void cacheSettings(int entityId, MobSettings settings) {
        ClientEvents.PENDING.put(Integer.valueOf(entityId), settings);
    }

    @Override
    public void handleVisual(final Packets.Visual v) {
        Scheduler.CLIENT.add(new Runnable() {
            @Override
            public void run() {
                World w = Minecraft.getMinecraft().theWorld;
                if (w == null) return;
                Entity e = w.getEntityByID(v.entityId);
                if (e instanceof EntityLivingBase) {
                    MobEditor.applyVisualClient((EntityLivingBase) e, v.scale, v.boss, v.bossName);
                }
            }
        });
    }
}
