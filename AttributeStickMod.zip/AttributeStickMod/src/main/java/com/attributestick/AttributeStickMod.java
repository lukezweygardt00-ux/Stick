package com.attributestick;

import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.network.NetworkRegistry;
import cpw.mods.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.relauncher.Side;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;

@Mod(modid = AttributeStickMod.MODID, name = "Attribute Stick", version = AttributeStickMod.VERSION)
public class AttributeStickMod {

    public static final String MODID = "attributestick";
    public static final String VERSION = "1.0.0";

    @Mod.Instance(MODID)
    public static AttributeStickMod instance;

    @SidedProxy(clientSide = "com.attributestick.ClientProxy", serverSide = "com.attributestick.CommonProxy")
    public static CommonProxy proxy;

    public static SimpleNetworkWrapper network;
    public static Item stick;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        stick = new ItemAttributeStick();
        GameRegistry.registerItem(stick, "attributeStick");

        network = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        network.registerMessage(Packets.Open.Handler.class, Packets.Open.class, 0, Side.CLIENT);
        network.registerMessage(Packets.Apply.Handler.class, Packets.Apply.class, 1, Side.SERVER);
        network.registerMessage(Packets.Visual.Handler.class, Packets.Visual.class, 2, Side.CLIENT);
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        NetworkRegistry.INSTANCE.registerGuiHandler(this, new GuiHandler());

        StickEvents events = new StickEvents();
        FMLCommonHandler.instance().bus().register(events);   // server ticks
        MinecraftForge.EVENT_BUS.register(events);            // entity events

        GameRegistry.addShapedRecipe(new ItemStack(stick),
                " E ",
                " S ",
                " D ",
                'E', Items.ender_pearl, 'S', Items.stick, 'D', Items.diamond);

        proxy.init();
    }
}
