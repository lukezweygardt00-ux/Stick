package com.attributestick;

import cpw.mods.fml.common.network.ByteBufUtils;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.nbt.NBTTagCompound;

/**
 * Everything the Attribute Stick can change on a mob (except equipment, which is handled by
 * the slots in the GUI). Plain data: can be sent over the network and saved to NBT.
 */
public class MobSettings {

    /** Key of the settings compound inside Entity#getEntityData() (Forge saves that with the mob). */
    public static final String TAG = "AttributeStick";
    /** Key of the compound that remembers the mob's original values so "Reset" works. */
    public static final String ORIG = "AttributeStickOrig";

    public static final int MODE_VANILLA = 0;
    public static final int MODE_HOSTILE = 1;
    public static final int MODE_NORMAL = 2;
    public static final int MODE_FRIENDLY = 3;

    public double maxHealth = 20.0;
    public double damage = 2.0;
    public double speed = 0.25;
    public double kbResist = 0.0;
    public double followRange = 32.0;
    /** Extra knockback this mob deals to whatever it hits. 0 = normal, ~10 = launched across the map. */
    public float knockback = 0.0F;
    /** Size multiplier. 1 = normal. */
    public float scale = 1.0F;
    public String name = "";
    public String bossName = "";
    public boolean bossBar = false;
    public boolean invulnerable = false;
    public int mode = MODE_VANILLA;

    // ---- reading the current state of a mob ---------------------------------------------

    public static double base(EntityLivingBase e, IAttribute attr, double fallback) {
        IAttributeInstance a = e.getEntityAttribute(attr);
        return a == null ? fallback : a.getBaseValue();
    }

    /** Current values of a mob, used to fill the GUI. */
    public static MobSettings read(EntityLivingBase e) {
        MobSettings s = new MobSettings();
        s.maxHealth = base(e, SharedMonsterAttributes.maxHealth, e.getMaxHealth());
        s.damage = base(e, SharedMonsterAttributes.attackDamage, 2.0);
        s.speed = base(e, SharedMonsterAttributes.movementSpeed, 0.25);
        s.kbResist = base(e, SharedMonsterAttributes.knockbackResistance, 0.0);
        s.followRange = base(e, SharedMonsterAttributes.followRange, 32.0);
        if (e instanceof EntityLiving) {
            String n = ((EntityLiving) e).getCustomNameTag();
            s.name = n == null ? "" : n;
        }
        NBTTagCompound root = e.getEntityData();
        if (root.hasKey(TAG, 10)) {
            NBTTagCompound t = root.getCompoundTag(TAG);
            s.knockback = t.getFloat("Knockback");
            s.scale = t.getFloat("Scale");
            if (s.scale <= 0.0F) s.scale = 1.0F;
            s.bossBar = t.getBoolean("BossBar");
            s.bossName = t.getString("BossName");
            s.invulnerable = t.getBoolean("Invulnerable");
            s.mode = t.getInteger("Mode");
        }
        return s;
    }

    // ---- NBT ---------------------------------------------------------------------------

    public NBTTagCompound toTag() {
        NBTTagCompound t = new NBTTagCompound();
        t.setDouble("MaxHealth", maxHealth);
        t.setDouble("Damage", damage);
        t.setDouble("Speed", speed);
        t.setDouble("KbResist", kbResist);
        t.setDouble("FollowRange", followRange);
        t.setFloat("Knockback", knockback);
        t.setFloat("Scale", scale);
        t.setString("Name", name);
        t.setString("BossName", bossName);
        t.setBoolean("BossBar", bossBar);
        t.setBoolean("Invulnerable", invulnerable);
        t.setInteger("Mode", mode);
        return t;
    }

    public static MobSettings fromTag(NBTTagCompound t) {
        MobSettings s = new MobSettings();
        s.maxHealth = t.getDouble("MaxHealth");
        s.damage = t.getDouble("Damage");
        s.speed = t.getDouble("Speed");
        s.kbResist = t.getDouble("KbResist");
        s.followRange = t.getDouble("FollowRange");
        s.knockback = t.getFloat("Knockback");
        s.scale = t.getFloat("Scale");
        s.name = t.getString("Name");
        s.bossName = t.getString("BossName");
        s.bossBar = t.getBoolean("BossBar");
        s.invulnerable = t.getBoolean("Invulnerable");
        s.mode = t.getInteger("Mode");
        return s.sanitize();
    }

    // ---- network -----------------------------------------------------------------------

    public void toBytes(ByteBuf buf) {
        buf.writeDouble(maxHealth);
        buf.writeDouble(damage);
        buf.writeDouble(speed);
        buf.writeDouble(kbResist);
        buf.writeDouble(followRange);
        buf.writeFloat(knockback);
        buf.writeFloat(scale);
        ByteBufUtils.writeUTF8String(buf, name);
        ByteBufUtils.writeUTF8String(buf, bossName);
        buf.writeBoolean(bossBar);
        buf.writeBoolean(invulnerable);
        buf.writeByte(mode);
    }

    public static MobSettings fromBytes(ByteBuf buf) {
        MobSettings s = new MobSettings();
        s.maxHealth = buf.readDouble();
        s.damage = buf.readDouble();
        s.speed = buf.readDouble();
        s.kbResist = buf.readDouble();
        s.followRange = buf.readDouble();
        s.knockback = buf.readFloat();
        s.scale = buf.readFloat();
        s.name = ByteBufUtils.readUTF8String(buf);
        s.bossName = ByteBufUtils.readUTF8String(buf);
        s.bossBar = buf.readBoolean();
        s.invulnerable = buf.readBoolean();
        s.mode = buf.readByte();
        return s;
    }

    // ---- validation --------------------------------------------------------------------

    private static double clamp(double v, double lo, double hi) {
        if (Double.isNaN(v) || Double.isInfinite(v)) return lo;
        return v < lo ? lo : (v > hi ? hi : v);
    }

    /** Clamp everything to values the game can handle (never trust the client). */
    public MobSettings sanitize() {
        maxHealth = clamp(maxHealth, 1.0, 1024.0);
        damage = clamp(damage, 0.0, 2048.0);
        speed = clamp(speed, 0.0, 5.0);
        kbResist = clamp(kbResist, 0.0, 1.0);
        followRange = clamp(followRange, 1.0, 2048.0);
        knockback = (float) clamp(knockback, 0.0, 50.0);
        scale = (float) clamp(scale, 0.1, 16.0);
        if (name == null) name = "";
        if (bossName == null) bossName = "";
        if (name.length() > 64) name = name.substring(0, 64);
        if (bossName.length() > 64) bossName = bossName.substring(0, 64);
        if (mode < 0 || mode > 3) mode = MODE_VANILLA;
        return this;
    }
}
