package com.attributestick;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingSetAttackTargetEvent;
import net.minecraftforge.event.entity.living.LivingUpdateEvent;
import net.minecraftforge.event.entity.player.EntityInteractEvent;

/** All the game-logic hooks. Registered on both the Forge bus and the FML bus. */
public class StickEvents {

    private static final String KB_X = "AS_KBX";
    private static final String KB_Y = "AS_KBY";
    private static final String KB_Z = "AS_KBZ";

    // ---- helpers -------------------------------------------------------------------------

    /** Creative players, ops, and anyone in singleplayer may use the stick. */
    public static boolean canEdit(EntityPlayerMP p) {
        if (p.capabilities.isCreativeMode) return true;
        if (p.canCommandSenderUseCommand(2, "")) return true;
        MinecraftServer server = MinecraftServer.getServer();
        return server != null && server.isSinglePlayer();
    }

    /** The stick's settings of a mob, or null if it was never edited. */
    private static NBTTagCompound settingsOf(Entity e) {
        if (!(e instanceof EntityLivingBase)) return null;
        NBTTagCompound d = e.getEntityData();
        if (d.hasNoTags() || !d.hasKey(MobSettings.TAG, 10)) return null;
        return d.getCompoundTag(MobSettings.TAG);
    }

    // ---- right click with the stick -------------------------------------------------------

    @SubscribeEvent
    public void onInteract(EntityInteractEvent event) {
        EntityPlayer player = event.entityPlayer;
        ItemStack held = player.getHeldItem();
        if (held == null || held.getItem() != AttributeStickMod.stick) return;
        if (!(event.target instanceof EntityLiving)) return;

        // swallow the click on both sides so the mob's own right-click action (trading, riding...) doesn't happen
        event.setCanceled(true);
        if (player.worldObj.isRemote) return;

        EntityPlayerMP p = (EntityPlayerMP) player;
        if (!canEdit(p)) {
            p.addChatMessage(new ChatComponentText(EnumChatFormatting.RED
                    + "The Attribute Stick only works in creative mode, for ops, or in singleplayer."));
            return;
        }
        EntityLiving mob = (EntityLiving) event.target;
        MobEditor.ensureOriginals(mob);
        AttributeStickMod.network.sendTo(new Packets.Open(mob.getEntityId(), MobSettings.read(mob)), p);
        p.openGui(AttributeStickMod.instance, 0, p.worldObj, mob.getEntityId(), 0, 0);
    }

    // ---- loading edited mobs back in -----------------------------------------------------

    @SubscribeEvent
    public void onJoin(EntityJoinWorldEvent event) {
        if (event.world.isRemote) return;
        if (event.entity instanceof EntityLivingBase) {
            MobEditor.applyStored((EntityLivingBase) event.entity);
        }
    }

    // ---- per tick ------------------------------------------------------------------------

    @SubscribeEvent
    public void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.START) {
            Scheduler.drain(Scheduler.SERVER);
        }
    }

    @SubscribeEvent
    public void onLivingUpdate(LivingUpdateEvent event) {
        EntityLivingBase e = event.entityLiving;
        NBTTagCompound d = e.getEntityData();
        if (d.hasNoTags()) return;

        // delayed knockback (vanilla knockback is applied in the same tick as the hit and would halve ours)
        if (!e.worldObj.isRemote && d.hasKey(KB_X)) {
            e.motionX += d.getFloat(KB_X);
            e.motionY += d.getFloat(KB_Y);
            e.motionZ += d.getFloat(KB_Z);
            e.velocityChanged = true;
            d.removeTag(KB_X);
            d.removeTag(KB_Y);
            d.removeTag(KB_Z);
        }

        if (!d.hasKey(MobSettings.TAG, 10)) return;
        NBTTagCompound t = d.getCompoundTag(MobSettings.TAG);

        // some mobs reset their own hitbox now and then; keep ours
        float scale = t.getFloat("Scale");
        if (scale > 0.0F && scale != 1.0F) {
            MobEditor.applySize(e, scale);
        }

        // players that walk into range later need the size / boss bar info too
        if (!e.worldObj.isRemote && e.ticksExisted % 100 == 7) {
            MobEditor.broadcastVisual(e);
        }
    }

    // ---- combat --------------------------------------------------------------------------

    @SubscribeEvent
    public void onAttack(LivingAttackEvent event) {
        Entity attacker = event.source.getEntity();
        NBTTagCompound a = settingsOf(attacker);
        if (a != null && a.getInteger("Mode") == MobSettings.MODE_FRIENDLY) {
            event.setCanceled(true);   // friendly mobs never hurt anything
            return;
        }
        NBTTagCompound v = settingsOf(event.entityLiving);
        if (v != null && v.getBoolean("Invulnerable") && !event.source.canHarmInCreative()) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public void onHurt(LivingHurtEvent event) {
        Entity attacker = event.source.getEntity();
        NBTTagCompound a = settingsOf(attacker);
        if (a == null) return;
        float k = a.getFloat("Knockback");
        if (k <= 0.0F) return;

        EntityLivingBase victim = event.entityLiving;
        double dx = victim.posX - attacker.posX;
        double dz = victim.posZ - attacker.posZ;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.0E-4) {
            double angle = victim.worldObj.rand.nextDouble() * Math.PI * 2.0;
            dx = Math.cos(angle);
            dz = Math.sin(angle);
            len = 1.0;
        }
        double horizontal = k * 0.5;
        double vertical = Math.min(0.2 + k * 0.1, 4.0);

        NBTTagCompound d = victim.getEntityData();
        d.setFloat(KB_X, (float) (dx / len * horizontal));
        d.setFloat(KB_Y, (float) vertical);
        d.setFloat(KB_Z, (float) (dz / len * horizontal));
    }

    @SubscribeEvent
    public void onSetTarget(LivingSetAttackTargetEvent event) {
        if (event.target == null) return;
        if (!(event.entityLiving instanceof EntityLiving)) return;
        NBTTagCompound s = settingsOf(event.entityLiving);
        if (s != null && s.getInteger("Mode") == MobSettings.MODE_FRIENDLY) {
            ((EntityLiving) event.entityLiving).setAttackTarget(null);
        }
    }
}
